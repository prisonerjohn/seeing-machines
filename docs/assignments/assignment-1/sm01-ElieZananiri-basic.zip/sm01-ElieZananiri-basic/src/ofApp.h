#pragma once

#include "ofMain.h"

class ofApp : public ofBaseApp
{
public:
	void setup();
	void update();
	void draw();

	ofColor liveColor;
	ofColor deadColor;

	ofImage lifeImg;
};
