#include "ofApp.h"

void ofApp::setup()
{
	ofSetFrameRate(12);

	runOnce = false;
	runAlways = false;

	// Cache the live/dead colors into variables.
	liveColor = ofColor(255);
	deadColor = ofColor(0);

	lifeImg.allocate(40, 30, OF_IMAGE_GRAYSCALE);
	// Set the texture interpolation mode to nearest pixel, to keep the image sharp when scaling it up.
	// The default is GL_LINEAR (linear interpolation), which blends the pixels when scaling up.
	lifeImg.getTexture().setTextureMinMagFilter(GL_NEAREST, GL_NEAREST);

	initRandom();

	ofSetWindowShape(lifeImg.getWidth() * 10, lifeImg.getHeight() * 10);
}

void ofApp::update()
{
	if (runOnce || runAlways)
	{
		// Iterate through the pixels and count the live neighbors.
		ofPixels lifePix = lifeImg.getPixels();
		for (int y = 0; y < lifeImg.getHeight(); y++)
		{
			for (int x = 0; x < lifeImg.getWidth(); x++)
			{
				// Setup the neighbor indices, wrapping around if we are on an edge.
				int xLeft = x - 1;
				if (xLeft < 0)
				{
					xLeft += lifeImg.getWidth();
				}
				int xRight = (x + 1) % (int)lifeImg.getWidth();
				int yUp = y - 1;
				if (yUp < 0)
				{
					yUp += lifeImg.getHeight();
				}
				int yDown = (y + 1) % (int)lifeImg.getHeight();

				// Count the live neighbors.
				// Make sure to skip the pixel itself!
				int liveNeighbors = 0;
				if (lifeImg.getColor(xLeft, yUp) == liveColor)
				{
					liveNeighbors++;
				}
				if (lifeImg.getColor(xLeft, y) == liveColor)
				{
					liveNeighbors++;
				}
				if (lifeImg.getColor(xLeft, yDown) == liveColor)
				{
					liveNeighbors++;
				}
				if (lifeImg.getColor(x, yUp) == liveColor)
				{
					liveNeighbors++;
				}
				if (lifeImg.getColor(x, yDown) == liveColor)
				{
					liveNeighbors++;
				}
				if (lifeImg.getColor(xRight, yUp) == liveColor)
				{
					liveNeighbors++;
				}
				if (lifeImg.getColor(xRight, y) == liveColor)
				{
					liveNeighbors++;
				}
				if (lifeImg.getColor(xRight, yDown) == liveColor)
				{
					liveNeighbors++;
				}

				// Apply the rules.
				if (lifeImg.getColor(x, y) == liveColor)
				{
					// Live cell.
					if (liveNeighbors <= 1)
					{
						// Isolation rule.
						// 
						// Set the color on the ofPixels copy, not on the original ofImage,
						// so that it gets updated for the next frame.
						lifePix.setColor(x, y, deadColor);
					}
					else if (liveNeighbors >= 4)
					{
						// Overcrowding rule.
						// 
						// Set the color on the ofPixels copy, not on the original ofImage,
						// so that it gets updated for the next frame.
						lifePix.setColor(x, y, deadColor);
					}
				}
				else
				{
					// Dead cell.
					if (liveNeighbors == 3)
					{
						// Birth rule.
						// 
						// Set the color on the ofPixels copy, not on the original ofImage,
						// so that it gets updated for the next frame.
						lifePix.setColor(x, y, liveColor);
					}
				}
			}
		}
		// Apply the changes back to the image.
		lifeImg.setFromPixels(lifePix);

		runOnce = false;
	}
}

void ofApp::draw()
{
	ofSetColor(255);
	lifeImg.draw(0, 0, ofGetWidth(), ofGetHeight());
}

void ofApp::keyPressed(int key)
{
	if (key == '1')
	{
		initRandom();
	}
	else if (key == '2')
	{
		initSolid(liveColor);
	}
	else if (key == '3')
	{
		initSolid(deadColor);
	}
	else if (key == '`')
	{
		runOnce = true;
		runAlways = false;
	}
	else if (key == ' ')
	{
		runAlways = !runAlways;
	}
}

void ofApp::mousePressed(int x, int y, int button)
{
	// This only works if the simulation is not running (otherwise the change gets overwritten)!
	x /= 10;
	y /= 10;
	ofPixels lifePix = lifeImg.getPixels();
	if (lifePix.getColor(x, y) == deadColor)
	{
		lifePix.setColor(x, y, liveColor);
	}
	else
	{
		lifePix.setColor(x, y, deadColor);
	}
	lifeImg.setFromPixels(lifePix);
}

void ofApp::initSolid(ofColor color)
{
	// Initialize image with a solid grid of the parameter color.
	ofPixels lifePix = lifeImg.getPixels();
	for (int y = 0; y < lifeImg.getHeight(); y++)
	{
		for (int x = 0; x < lifeImg.getWidth(); x++)
		{
			lifePix.setColor(x, y, color);
		}
	}
	lifeImg.setFromPixels(lifePix);
}

void ofApp::initRandom()
{
	// Initialize image with a random grid of live and dead cells.
	ofPixels lifePix = lifeImg.getPixels();
	for (int y = 0; y < lifeImg.getHeight(); y++)
	{
		for (int x = 0; x < lifeImg.getWidth(); x++)
		{
			if (ofRandomuf() < 0.5)
			{
				lifePix.setColor(x, y, deadColor);
			}
			else
			{
				lifePix.setColor(x, y, liveColor);
			}
		}
	}
	lifeImg.setFromPixels(lifePix);
}
