#pragma once

#include "ofMain.h"

class ofApp : public ofBaseApp
{
public:
	void setup();
	void update();
	void draw();

	void keyPressed(int key);
	void mousePressed(int x, int y, int button);

	void initSolid(ofColor color);
	void initRandom();

	ofColor liveColor;
	ofColor deadColor;

	ofImage lifeImg;

	bool runOnce;
	bool runAlways;
};
